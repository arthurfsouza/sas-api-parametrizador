import{f as a}from"./chunk-GEE2VHDD.js";import"./chunk-5G2P3N6K.js";export{a as ParametrizadorComponent};
