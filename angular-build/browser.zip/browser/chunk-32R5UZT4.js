import{a}from"./chunk-KPF4HMR2.js";import"./chunk-EFTF4FYJ.js";import"./chunk-WVOC2IMA.js";import"./chunk-4C2LNBUZ.js";import"./chunk-V4QFN6JK.js";export{a as ParametrizadorComponent};
